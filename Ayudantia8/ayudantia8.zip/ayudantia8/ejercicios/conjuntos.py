def conjuntos():
    x = {1, 1, 2, 3, 5, 8, 13}
    y = {2, 3, 5, 7, 11, 13}
    print(x | y)
    print(x & y)
    print(x - y)
    print(y - x)
    print(x ^ y)
